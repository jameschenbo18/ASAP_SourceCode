All plotting scripts should be placed in the same file folder containing the input files for the script.
########################################################################################################################
1. Plot_survivalbility.py: It is to make the same figure as Fig. 3D in manuscript. It predicts the N_a(n_g=2) and N_a(n_g=1) using Eqs. 13, 20 and 21 in manuscript.
   No input files are needed for this script. 
   Pls update the following parameters before executing the script.
    1. nstep(line 12, the number of annealin steps), 
    2. npeak_nca(line 13, the number of residue type assignments in ncacx input), 
    3. nres(line 14, the number of residues in your protein),
    4. nattempt(line 15, the number of Monte Carlo attempts at each annealing step),
    5. scale(line 16. the scalar to control the annealing slope in manuscript),
    6. w1i, w1f, w2i, w2f, w3i, w3f, w4i, and w4f for each coefficient of score function.
#########################################################################################################################
2. Plot_nmatch.py. It is to make the same figure as Fig. 3A in manuscript. It plots the number of matched pair identified by ARTIST against those consistenly allocated 
   residue type assignments in ncacx.
   Input files: knmatch_rd.txt and Consistencynca_summary.txt.
   Pls update the following parameters before executing the script.
    1. npeak_nca(line 13, the number of residue type assignments in ncacx input).
##########################################################################################################################
3. Plot_number.py. It is to make the same figure as Fig. 3B in manuscript. It plots the progression of the total n_g, n_b, n_e, and n_used along annealing.
   Input files: number_record.txt.
   Pls update the following parameters before executing the script.
    1.nstep(line 11, the number of annealin steps).
##########################################################################################################################
4. Plot_occupancy_sum.py. It is to make the same figure as Fig. 3C in manuscript. It plots the total counts of occupancies at each residue position along annealing.
   Input files: occupancy_sum.txt.
   Pls update the following parameters before executing the script.
    1.nstep(line 12, the number of annealin steps),
    2.npeak_nca(line 13, the number of residue type assignments in ncacx input), 
    3.nres(line 14, the number of residues in your protein).
##########################################################################################################################
5. Plot_Instigator.py. It is to make the same figure as Fig. S3 in manuscript. It plots the total counts of allocation of each residue type assignment along annealing.
   Input files: instigator.txt.
   Pls update the following parameters before executing the script.
    1.nstep(line 12, the number of annealin steps),
    2.npeak_nca(line 13, the number of residue type assignments in ncacx input), 
##########################################################################################################################
6. Plot_occupancy_step.py. It is to make the same figure as Fig. S4A and S4B in manuscript. It plots the total counts of each residue type assignment (x coordinate)
   at each residue positiion (y coordinate) at specified annealing step.
   Input files: occupancy_step.txt.
   Pls update the following parameters before executing the script.
    1.nstep(line 14, the number of annealin steps),
    2.npeak_nca(line 15, the number of residue type assignments in ncacx input), 
    3.nres(line 16, the number of residues in your protein),
    4.step2c(line17, the annealing step you wish to see the results).
##########################################################################################################################
7. Plot_neighbor.py. It is to make the same figure as Fig. S4C and S4D in manuscript. It plots the total counts of residue type assignments (x coordinate)
   allocted to the neighboring positions of each residue positiion (y coordinate) at specified annealing step.
   Input files: neighbor.txt.
   Pls update the following parameters before executing the script.
    1.nstep(line 14, the number of annealin steps),
    2.npeak_nca(line 15, the number of residue type assignments in ncacx input), 
    3.nres(line 17, the number of residues in your protein),
    4.step2c(line16, the annealing step you wish to see the results).
 