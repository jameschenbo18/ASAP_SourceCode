# -*- coding: utf-8 -*-
"""
Created on Sat Apr 22 14:51:01 2023

@author: FeiMao
"""
import numpy as np
import matplotlib.pyplot as plt

plot_filename1 = 'number_record.txt'
nstep = 10
#npeak_nca = 230 
#chosen_res = 11 
z_min = 0 
z_max = 0
step_index = [i for i in range(nstep+1)]
ngood_step = [0 for i in range(nstep+1)]
nbad_step = [0 for i in range(nstep+1)]
nedge_step = [0 for i in range(nstep+1)]
nused_step = [0 for i in range(nstep+1)]
with open(plot_filename1, "r") as file1:  
    i1 = 0
    #print(file1)
    for line in file1:
        line1=line.split( )
        ngood_step[i1] = float(line1[0])
        nbad_step[i1] = float(line1[1])
        nedge_step[i1] = float(line1[2])
        nused_step[i1] = float(line1[3])
        i1 += 1

plt.close('all')        
#fig = plt.figure(figsize = (20, 10))
plt.figure(figsize=(20,10), dpi=300)  
# creating the bar plot
plt.scatter(step_index, ngood_step, color ='red',
         marker = 'o',edgecolor ='grey',label ='no. of good connections')
plt.scatter(step_index, nbad_step, color ='blue',
         marker = 'v',edgecolor ='grey',label ='no. of bad connections')
plt.scatter(step_index, nedge_step, color ='green',
         marker = 's',edgecolor ='grey',label ='no. of edge connections')
plt.scatter(step_index, nused_step, color ='magenta',
         marker = 'D',edgecolor ='grey',label ='no. of used nca asgnments')
plt.rc('xtick', labelsize=32) 
plt.rc('ytick', labelsize=32)
plt.xlabel("MCSA step index",fontsize=32)
plt.ylabel("Counts",fontsize=32)
plt.title("Evolution of numbers during MCSA simulations",fontsize=32,fontweight='bold')

plt.legend()
plt.show()
