# -*- coding: utf-8 -*-
"""
Created on Sat Apr 22 14:51:01 2023

@author: FeiMao
"""
import numpy as np
import matplotlib.pyplot as plt

plot_filename1 = 'knmatch_rd.txt'
plot_filename2 = 'Consistencynca_summary.txt'
#nstep = 40
npeak_nca = 230 
#chosen_res = 11 
z_min = 0 
z_max = 0
nca_asgn = [i for i in range(npeak_nca+1)]
nmatch = [0 for i in range(npeak_nca+1)]
consistency = [0 for i in range(npeak_nca+1)]
tot_consistent = 0 
with open(plot_filename1, "r") as file1:  
    i1 = 0
    #print(file1)
    for line in file1: 
        nca_asgn[i1] = i1
        nmatch[i1]= int(line)
        i1 += 1
y_limit = max(nmatch)

with open(plot_filename2, "r") as file1:  
    i1 = 0
    #print(file1)
    for line in file1: 
        #nca_asgn[i1] = i1
        consistency[i1] = 100*int(line)
        tot_consistent += int(line)
        i1 += 1
plt.close('all')        
#fig = plt.figure(figsize = (20, 10))
plt.figure(figsize=(20,10), dpi=300)  
# creating the bar plot
plt.bar(nca_asgn, consistency, color ='grey',
        width = 1, edgecolor ='grey',label ='Consistent asgned')
plt.bar(nca_asgn, nmatch, color ='red',
        width = 1, edgecolor ='black',label ='No. of matched asgn')

print('there are ', tot_consistent,' residues assigned consistently.')
plt.xlabel("ncacx asgn input index")
plt.ylabel("No. of matched ncocx asgn")
plt.title("Number of matched asgn in nco for each nca input")
plt.xlim(0, npeak_nca+1)
plt.ylim(0, y_limit+1)
plt.legend()
plt.show()
