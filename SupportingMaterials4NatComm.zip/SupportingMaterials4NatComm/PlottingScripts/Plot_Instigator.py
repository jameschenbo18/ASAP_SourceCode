# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import matplotlib.pyplot as plt
#plt.style.use('seaborn-white')
import math
import numpy as np
plot_filename = 'instigator.txt'
nstep = 40
npeak_nca = 230 
z_min = 1 
z_max = 0 
    
col=[0 for i in range(npeak_nca+1)]
row=[0 for i in range(nstep+1)]
z=[[0 for i in range(len(col))] for i in range(len(row))]

        
with open(plot_filename, "r") as file1:  
    i1 = 0
    print(file1)
    for line in file1:
        line1=line.split( )
        row[i1] = i1
        
        for i2 in range(len(line1)):
            col[i2]=i2
            z[i1][i2] = float(line1[i2])
            if z[i1][i2] > 0 :
                if z_min >= z[i1][i2]:
                    z_min = z[i1][i2]
            if z_max <= z[i1][i2]:
                z_max = z[i1][i2]
        i1 += 1
        
vmin = z_min
vmax = z_max
fig = plt.figure(figsize=(30,60*nstep/npeak_nca), dpi=300)
ax =plt.imshow(z, norm='log',cmap='RdBu_r',interpolation='nearest',origin = 'lower', aspect='auto',vmin = z_min,vmax = z_max)
plt.colorbar();
plt.rc('xtick', labelsize=32) 
plt.rc('ytick', labelsize=32)
plt.title("Assignment migration frequency along MCSA progress",fontweight = 'bold', fontsize=32)
plt.xlabel('ncacx asgn index',fontsize=32)
plt.ylabel('MCSA step',fontsize=32)
#plt.legend()
plt.show()