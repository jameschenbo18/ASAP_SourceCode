# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import matplotlib.pyplot as plt
from matplotlib.backend_bases import MouseButton
import numpy as np
import math


plot_filename = 'neighbor.txt'
nstep = 400
npeak_nca = 230 
step2c = 5 
nres = 230
row_i = (nres + 1) * (step2c - 1)
row_f = (nres + 1) * (step2c) - 1 
z_min = 1 
z_max = 1.1 
    
col=[0 for i in range(npeak_nca+1)]
row=[0 for i in range(nres+1)]

z=[[0 for i in range(len(col))] for i in range(len(row))]
#z1=[0 for i in range(len(col))] 
#print('I am here')
        
with open(plot_filename, "r") as file1: 
    
    i1 = 0
    #print(file1)
    for line in file1:
        #print(i1)
        if i1 >= row_i and i1 <= row_f:
            line1=line.split( )
            counter = i1 - row_i  
            row[counter] = i1 - row_i 
        
            for i2 in range(len(line1)):
                col[i2]=i2
                z[counter][i2] = float(line1[i2])
                #print(z[counter][i2])
                if counter > 0 and i2 > 0:
                    if z_min >= z[counter][i2] and z[counter][i2] > 0:
                        z_min = z[counter][i2]
                        min_loc = [counter, i2]
                    if z_max <= z[counter][i2]:
                        z_max = z[counter][i2]
                        max_loc = [counter, i2]
            
        i1 += 1


fig = plt.figure(figsize=(30,30), dpi=300)    


    


#plt.contour(col,row, z, 100, cmap=plt.cm.get_cmap('RdBu_r'),vmin = z_min,vmax = z_max);#reverse red to blue
ax =plt.imshow(z, norm='log',cmap='RdBu_r',interpolation='nearest',origin = 'lower',vmin = z_min,vmax = z_max)
plt.colorbar();
plt.rc('xtick', labelsize=32) 
plt.rc('ytick', labelsize=32)
plt.title("Neighboring residues for MCSA step "+str(step2c),fontsize=32,fontweight='bold')
plt.xlabel('ncacx asgn at neighboring positions to specified asgn',fontsize=32)
plt.ylabel('asgn index in ncacx',fontsize=32)



plt.show()
