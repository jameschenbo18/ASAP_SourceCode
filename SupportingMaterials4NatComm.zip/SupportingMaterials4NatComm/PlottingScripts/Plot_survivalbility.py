# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import matplotlib.pyplot as plt
#plt.style.use('seaborn-white')
import math
import numpy as np
#plot_filename = 'occupancy_sum.txt'
nstep = 40
npeak_nca = 230 
nres = 230 
nattempt =  5000000
scale = 0.45#0.25#1#0.45
rc = 20 #ratio to keep good asgn/ remove local minimum for lower bound 
rs = 20 #ratio to keep good asgn/ remove local minimum for upper bound
w1i = 0 # w1 initial value  
w1f = 20#20#10#20 # w1 final value 
w2i = 0 # w2 initial value
w2f = 50#50#20#50 # w2 final value
w3i = 0 # w3 initial value
w3f = 5#5#2.5#5 # w3 final value 
w4i = 0 # w4 initial value
w4f = 10#10#5#10 # w4 final value

w1inc=(w1f-w1i)/nstep * scale
w2inc=(w2f-w2i)/nstep * scale
w3inc=(w3f-w3i)/nstep * scale
w4inc=(w4f-w4i)/nstep * scale
 
n0_mcsa = nattempt / (6*nres * 2/20)  #107 is the 1-(35/36)**107 = 0.95
n0_asap = 10*nattempt / 3 /nres / nres #17 is the 1-(5/6)**17 = 0.95

z_min = 1 
z_max = 0 

mcsa_step = [i for i in range(nstep+1)]

actual_attempt = [n0_asap for i in range(nstep+1)]

twogood_h = [0 for i in range(nstep+1)]#the number of required successful mc attempt to escape from local
#minimum via a null asgn, local minimum is with connections to both neighbors.
twogood_l = [0 for i in range(nstep+1)]#the number of required successful mc attempt to escape from local
#minimum via a null asgn, local minimum is with connections to both neighbors.
i_1mcsa = [0 for i in range(nstep+1)] #lower bound to start thorough annealing for standard MCSA
i_2mcsa = [0 for i in range(nstep+1)] #upper bound to start thorough annealing for standard MCSA
i_1asap = [0 for i in range(nstep+1)] #lower bound to start thorough annealing for asap
i_2asap = [0 for i in range(nstep+1)] #upper bound to start thorough annealing for asap
onegood_h = [0 for i in range(nstep+1)]#the number of required successful mc attempt to escape from local
#minimum via a null asgn, local minimum is with connections to one of two neighbors.
onegood_l = [0 for i in range(nstep+1)]#the number of required successful mc attempt to escape from local
#minimum via a null asgn, local minimum is with connections to one of two neighbors.

for istep in range(nstep+1):
    w1=w1i+(istep)*w1inc
    w2=w2i+(istep)*w2inc
    w3=w3i+(istep)*w3inc
    w4=w4i+(istep)*w4inc
    p_r4_2g =  math.exp(( w1 + w3) + 0.5 * w4 )
    p_r4_1g =  math.exp(0.5*(w1 + w4))
    twogood_h[istep] = p_r4_2g#num_attempt
    i_2mcsa[istep] = nstep/(w1f+w3f+w4f) * math.log (n0_mcsa*(rc+1))
    i_1mcsa[istep] = nstep/(w1f+w3f+w4f) * math.log ((rc+1))
    
    i_2asap[istep] = nstep/(2*w1f+2*w3f+w4f) * math.log (n0_asap*(rc+1))
    i_1mcsa[istep] = nstep/(2*w1f+2*w3f+w4f) * math.log ((rc+1))
    #twogood_l[istep] = 2*p_r4_2g#num_attempt
    onegood_h[istep] = p_r4_1g
    #onegood_l[istep] = 2*p_r4_1g
plt.close('all')        
#fig = plt.figure(figsize = (20, 10))
plt.subplots(figsize=(20,10), dpi=300)  
# creating the bar plot
plt.scatter(mcsa_step, twogood_h, color ='red',marker = 'o',edgecolor ='grey',label ='barrier for two good connections')
#plt.scatter(mcsa_step, i_2mcsa, color ='red',marker = '^',edgecolor ='grey',label ='upper bound step for mcsa to start thorough sampling')
#plt.scatter(mcsa_step, i_1mcsa, color ='red',marker = 'v',edgecolor ='grey',label ='lower bound step for mcsa to start thorough sampling')

#plt.scatter(mcsa_step, i_2asap, color ='blue',marker = '^',edgecolor ='grey',label ='upper bound step for asap to start thorough sampling')
#plt.scatter(mcsa_step, i_1asap, color ='blue',marker = 'v',edgecolor ='grey',label ='lower bound step for asap to start thorough sampling')


plt.scatter(mcsa_step, onegood_h, color ='blue',marker = 'D',edgecolor ='grey',label ='barrier for one good connection')
#plt.scatter(mcsa_step, onegood_l, color ='blue',marker = 'd',edgecolor ='grey',label ='barrier for one good connection')

plt.scatter(mcsa_step, actual_attempt, color ='red',marker = '_',edgecolor ='grey',label ='available attempts')


plt.rc('xtick', labelsize=32) 
plt.rc('ytick', labelsize=32)
plt.xlabel("annealing step index",fontsize=32)
plt.ylabel("Monte Carlo attempts ",fontsize=32)
plt.title("Tc for MC attempt "+str(nattempt/1000000)+"mil scale "+str(scale)+" during MCSA simulations",fontsize=32,fontweight='bold')
#plt.ylim(0, barrier[1]+1)
# Set logarithmic scale on the y variable
plt.yscale("log");
plt.legend()
plt.show()